<?php
// customers/edit.php — Edit existing customer
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Edit Customer';
$rootPath  = '../';
$error = '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$stmt = $conn->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$customer) { header('Location: index.php?error=Customer not found.'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['customer_name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (empty($name) || empty($phone)) {
        $error = 'Customer name and phone are required.';
    } elseif ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = $conn->prepare("UPDATE customers SET customer_name=?, email=?, phone=?, address=? WHERE id=?");
        $stmt->bind_param('ssssi', $name, $email, $phone, $address, $id);
        if ($stmt->execute()) {
            header('Location: index.php?success=Customer updated successfully!');
            exit;
        } else {
            $error = 'Update failed. Please try again.';
        }
        $stmt->close();
    }
    $customer = array_merge($customer, $_POST);
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-pencil-square me-2" style="color:var(--gold);"></i>Edit Customer</h2>
            <p>Update record for: <strong><?php echo htmlspecialchars($customer['customer_name']); ?></strong></p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="form-card">
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="customer_name" class="form-control"
                               value="<?php echo htmlspecialchars($customer['customer_name']); ?>" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control"
                                   value="<?php echo htmlspecialchars($customer['email'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Phone Number *</label>
                            <input type="text" name="phone" class="form-control"
                                   value="<?php echo htmlspecialchars($customer['phone']); ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Address</label>
                        <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($customer['address'] ?? ''); ?></textarea>
                    </div>

                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-gold px-5 rounded-pill">
                            <i class="bi bi-check-lg me-2"></i>Update Customer
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
