<?php
// customers/index.php — View all customers
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Customers';
$rootPath  = '../';

$success = $_GET['success'] ?? '';
$error   = $_GET['error']   ?? '';
$search  = trim($_GET['search'] ?? '');

// Pagination
$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where = "WHERE 1=1";
$params = []; $types = '';
if ($search !== '') {
    $where .= " AND (customer_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%";
    $types .= 'sss';
}

$countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM customers $where");
if ($params) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['c'];
$totalPages = ceil($total / $perPage);
$countStmt->close();

$p2 = $params; $p2[] = $perPage; $p2[] = $offset; $t2 = $types . 'ii';
$stmt = $conn->prepare("SELECT * FROM customers $where ORDER BY id DESC LIMIT ? OFFSET ?");
$stmt->bind_param($t2, ...$p2);
$stmt->execute();
$customers = $stmt->get_result();
$stmt->close();

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
            <h2><i class="bi bi-people me-2" style="color:var(--gold);"></i>Customers</h2>
            <p>Manage customer records and information.</p>
        </div>
        <a href="add.php" class="btn btn-gold rounded-pill px-4">
            <i class="bi bi-plus-lg me-2"></i>Add Customer
        </a>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-custom alert-success-custom auto-dismiss mb-3">
        <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <!-- Search -->
    <div class="data-card mb-3">
        <div class="p-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-5 search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" name="search" class="form-control"
                           placeholder="Search by name, email, phone..."
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-auto d-flex gap-2">
                    <button type="submit" class="btn btn-gold rounded-pill px-4">Search</button>
                    <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="data-card">
        <div class="data-card-header">
            <h5>All Customers <span style="color:var(--text-muted);font-size:13px;font-family:'DM Sans';">(<?php echo $total; ?> records)</span></h5>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($customers->num_rows === 0): ?>
                    <tr><td colspan="7" class="text-center py-4" style="color:var(--text-muted);">No customers found.</td></tr>
                    <?php endif; ?>
                    <?php $sno = $offset + 1; while ($row = $customers->fetch_assoc()): ?>
                    <tr class="searchable-row">
                        <td><?php echo $sno++; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['customer_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['email'] ?: '—'); ?></td>
                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                        <td><?php echo htmlspecialchars(substr($row['address'] ?? '', 0, 35)) ?: '—'; ?></td>
                        <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn-action btn-edit me-1" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <button class="btn-action btn-delete"
                                    onclick="confirmDelete('delete.php?id=<?php echo $row['id']; ?>', '<?php echo htmlspecialchars($row['customer_name']); ?>')"
                                    title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php if ($totalPages > 1): ?>
        <div class="p-3 d-flex justify-content-end">
            <nav><ul class="pagination mb-0">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
            </ul></nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
