<?php
// customers/add.php — Add new customer
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Add Customer';
$rootPath  = '../';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['customer_name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    // Validation
    if (empty($name) || empty($phone)) {
        $error = 'Customer name and phone are required.';
    } elseif ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (!preg_match('/^[0-9\-\+\s]{7,20}$/', $phone)) {
        $error = 'Please enter a valid phone number.';
    } else {
        // Check duplicate email
        if ($email) {
            $chk = $conn->prepare("SELECT id FROM customers WHERE email = ?");
            $chk->bind_param('s', $email);
            $chk->execute();
            $chk->store_result();
            if ($chk->num_rows > 0) { $error = 'A customer with this email already exists.'; }
            $chk->close();
        }
        if (!$error) {
            $stmt = $conn->prepare("INSERT INTO customers (customer_name, email, phone, address) VALUES (?,?,?,?)");
            $stmt->bind_param('ssss', $name, $email, $phone, $address);
            if ($stmt->execute()) {
                header('Location: index.php?success=Customer added successfully!');
                exit;
            } else {
                $error = 'Failed to add customer.';
            }
            $stmt->close();
        }
    }
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-person-plus me-2" style="color:var(--gold);"></i>Add Customer</h2>
            <p>Register a new customer in the system.</p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="form-card">
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="customer_name" class="form-control"
                               placeholder="e.g. Ahmed Khan"
                               value="<?php echo htmlspecialchars($_POST['customer_name'] ?? ''); ?>" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control"
                                   placeholder="example@email.com"
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Phone Number *</label>
                            <input type="text" name="phone" class="form-control"
                                   placeholder="0300-1234567"
                                   value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Address</label>
                        <textarea name="address" class="form-control" rows="3"
                                  placeholder="Street, Area, City..."><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                    </div>

                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-gold px-5 rounded-pill">
                            <i class="bi bi-check-lg me-2"></i>Save Customer
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
