// js/script.js — RestoPro Custom JavaScript

// ---- Delete Confirmation ----
function confirmDelete(url, itemName) {
    if (confirm('⚠️ Are you sure you want to delete "' + itemName + '"?\n\nThis action cannot be undone.')) {
        window.location.href = url;
    }
}

// ---- Auto-dismiss alerts after 4 seconds ----
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.auto-dismiss');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 500);
        }, 4000);
    });

    // ---- Sidebar toggle on mobile ----
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });
    }

    // ---- Live search filter for tables ----
    const searchInput = document.getElementById('liveSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function () {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('.searchable-row');
            rows.forEach(function (row) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }

    // ---- Order total auto-calculator ----
    calcOrderTotal();
});

// ---- Calculate order total from item rows ----
function calcOrderTotal() {
    const totalEl = document.getElementById('orderTotal');
    if (!totalEl) return;

    function update() {
        let total = 0;
        document.querySelectorAll('.item-row').forEach(function (row) {
            const qty   = parseFloat(row.querySelector('.item-qty')?.value) || 0;
            const price = parseFloat(row.querySelector('.item-price')?.dataset.price) || 0;
            const sub   = qty * price;
            const subEl = row.querySelector('.item-subtotal');
            if (subEl) subEl.textContent = 'Rs. ' + sub.toFixed(2);
            total += sub;
        });
        totalEl.textContent = 'Rs. ' + total.toFixed(2);
    }

    document.addEventListener('change', function (e) {
        if (e.target.classList.contains('item-qty')) update();
    });
    update();
}
