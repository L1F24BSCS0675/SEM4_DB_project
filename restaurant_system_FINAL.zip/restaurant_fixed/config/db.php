<?php
// ============================================================
// config/db.php — Database Connection
// Port 3307 for XAMPP (non-default MySQL port)
// ============================================================

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'restaurant_db');
define('DB_PORT', 3307);

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

if ($conn->connect_error) {
    die("
    <div style='font-family:Arial;padding:40px;text-align:center;'>
        <h2 style='color:red;'>❌ Database Connection Failed</h2>
        <p>" . $conn->connect_error . "</p>
        <p>Make sure XAMPP MySQL is running and <strong>restaurant_db</strong> is imported.</p>
        <p><a href='/restaurant_system/import.php'>👉 Click here to import the database automatically</a></p>
    </div>");
}

$conn->set_charset("utf8mb4");
?>
