<?php
// tables/index.php — View all restaurant tables
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Restaurant Tables';
$rootPath  = '../';
$success = $_GET['success'] ?? '';
$error   = $_GET['error']   ?? '';
$search  = trim($_GET['search'] ?? '');

$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where = "WHERE 1=1"; $params = []; $types = '';
if ($search !== '') {
    $where .= " AND (table_number LIKE ? OR location LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%"; $types .= 'ss';
}

$countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM restaurant_tables $where");
if ($params) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['c'];
$totalPages = ceil($total / $perPage);
$countStmt->close();

$p2 = $params; $p2[] = $perPage; $p2[] = $offset; $t2 = $types . 'ii';
$stmt = $conn->prepare("SELECT * FROM restaurant_tables $where ORDER BY table_number ASC LIMIT ? OFFSET ?");
$stmt->bind_param($t2, ...$p2);
$stmt->execute();
$tables = $stmt->get_result();
$stmt->close();

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
            <h2><i class="bi bi-grid-3x3-gap me-2" style="color:var(--gold);"></i>Restaurant Tables</h2>
            <p>Manage dining tables and their availability.</p>
        </div>
        <a href="add.php" class="btn btn-gold rounded-pill px-4">
            <i class="bi bi-plus-lg me-2"></i>Add Table
        </a>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-custom alert-success-custom auto-dismiss mb-3">
        <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="data-card mb-3">
        <div class="p-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-5 search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" name="search" class="form-control"
                           placeholder="Search by table number or location..."
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-auto d-flex gap-2">
                    <button type="submit" class="btn btn-gold rounded-pill px-4">Search</button>
                    <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="data-card">
        <div class="data-card-header">
            <h5>All Tables <span style="color:var(--text-muted);font-size:13px;font-family:'DM Sans';">(<?php echo $total; ?> records)</span></h5>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Table No.</th>
                        <th>Capacity</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($tables->num_rows === 0): ?>
                    <tr><td colspan="6" class="text-center py-4" style="color:var(--text-muted);">No tables found.</td></tr>
                    <?php endif; ?>
                    <?php $sno = $offset + 1; while ($row = $tables->fetch_assoc()): ?>
                    <tr class="searchable-row">
                        <td><?php echo $sno++; ?></td>
                        <td><strong style="color:var(--gold);"><?php echo htmlspecialchars($row['table_number']); ?></strong></td>
                        <td><i class="bi bi-people me-1" style="color:var(--text-muted);"></i><?php echo $row['capacity']; ?> persons</td>
                        <td><?php echo htmlspecialchars($row['location']); ?></td>
                        <td>
                            <span class="badge-custom badge-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn-action btn-edit me-1" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <button class="btn-action btn-delete"
                                    onclick="confirmDelete('delete.php?id=<?php echo $row['id']; ?>', 'Table <?php echo htmlspecialchars($row['table_number']); ?>')"
                                    title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php if ($totalPages > 1): ?>
        <div class="p-3 d-flex justify-content-end">
            <nav><ul class="pagination mb-0">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
            </ul></nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
