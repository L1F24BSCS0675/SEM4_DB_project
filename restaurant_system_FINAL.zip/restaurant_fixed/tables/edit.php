<?php
// tables/edit.php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Edit Table';
$rootPath  = '../';
$error = '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$stmt = $conn->prepare("SELECT * FROM restaurant_tables WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$table = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$table) { header('Location: index.php?error=Table not found.'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table_number = trim($_POST['table_number'] ?? '');
    $capacity     = (int)($_POST['capacity'] ?? 0);
    $location     = trim($_POST['location'] ?? '');
    $status       = $_POST['status'] ?? 'available';

    if (empty($table_number) || $capacity < 1) {
        $error = 'Table number and capacity are required.';
    } else {
        $stmt = $conn->prepare("UPDATE restaurant_tables SET table_number=?, capacity=?, location=?, status=? WHERE id=?");
        $stmt->bind_param('sissi', $table_number, $capacity, $location, $status, $id);
        if ($stmt->execute()) {
            header('Location: index.php?success=Table updated successfully!');
            exit;
        } else {
            $error = 'Update failed.';
        }
        $stmt->close();
    }
    $table = array_merge($table, $_POST, ['capacity' => $capacity]);
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-pencil-square me-2" style="color:var(--gold);"></i>Edit Table</h2>
            <p>Update details for Table: <strong><?php echo htmlspecialchars($table['table_number']); ?></strong></p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="form-card">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Table Number *</label>
                            <input type="text" name="table_number" class="form-control"
                                   value="<?php echo htmlspecialchars($table['table_number']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Capacity (persons) *</label>
                            <input type="number" name="capacity" class="form-control" min="1" max="50"
                                   value="<?php echo $table['capacity']; ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Location</label>
                        <select name="location" class="form-select">
                            <?php
                            $locs = ['Main Hall','Window Side','Garden Area','VIP Room','Banquet Hall','Rooftop'];
                            foreach ($locs as $loc):
                            ?>
                            <option value="<?php echo $loc; ?>" <?php echo ($table['location'] === $loc) ? 'selected' : ''; ?>>
                                <?php echo $loc; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="available" <?php echo ($table['status'] === 'available') ? 'selected' : ''; ?>>Available</option>
                            <option value="occupied"  <?php echo ($table['status'] === 'occupied')  ? 'selected' : ''; ?>>Occupied</option>
                            <option value="reserved"  <?php echo ($table['status'] === 'reserved')  ? 'selected' : ''; ?>>Reserved</option>
                        </select>
                    </div>

                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-gold px-5 rounded-pill">
                            <i class="bi bi-check-lg me-2"></i>Update Table
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
