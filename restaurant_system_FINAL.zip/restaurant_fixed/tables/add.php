<?php
// tables/add.php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Add Table';
$rootPath  = '../';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table_number = trim($_POST['table_number'] ?? '');
    $capacity     = (int)($_POST['capacity'] ?? 0);
    $location     = trim($_POST['location'] ?? 'Main Hall');
    $status       = $_POST['status'] ?? 'available';

    if (empty($table_number) || $capacity < 1) {
        $error = 'Table number and capacity are required.';
    } else {
        // Check duplicate table number
        $chk = $conn->prepare("SELECT id FROM restaurant_tables WHERE table_number = ?");
        $chk->bind_param('s', $table_number);
        $chk->execute();
        $chk->store_result();
        if ($chk->num_rows > 0) {
            $error = 'Table number already exists.';
        } else {
            $stmt = $conn->prepare("INSERT INTO restaurant_tables (table_number, capacity, location, status) VALUES (?,?,?,?)");
            $stmt->bind_param('siss', $table_number, $capacity, $location, $status);
            if ($stmt->execute()) {
                header('Location: index.php?success=Table added successfully!');
                exit;
            } else {
                $error = 'Failed to add table.';
            }
            $stmt->close();
        }
        $chk->close();
    }
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-plus-circle me-2" style="color:var(--gold);"></i>Add Table</h2>
            <p>Add a new dining table to the restaurant.</p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="form-card">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Table Number *</label>
                            <input type="text" name="table_number" class="form-control"
                                   placeholder="e.g. T-11"
                                   value="<?php echo htmlspecialchars($_POST['table_number'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Capacity (persons) *</label>
                            <input type="number" name="capacity" class="form-control" min="1" max="50"
                                   placeholder="4"
                                   value="<?php echo htmlspecialchars($_POST['capacity'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Location</label>
                        <select name="location" class="form-select">
                            <?php
                            $locs = ['Main Hall','Window Side','Garden Area','VIP Room','Banquet Hall','Rooftop'];
                            foreach ($locs as $loc):
                            ?>
                            <option value="<?php echo $loc; ?>" <?php echo (($_POST['location'] ?? 'Main Hall') === $loc) ? 'selected' : ''; ?>>
                                <?php echo $loc; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="available" <?php echo (($_POST['status'] ?? 'available') === 'available') ? 'selected' : ''; ?>>Available</option>
                            <option value="occupied"  <?php echo (($_POST['status'] ?? '') === 'occupied')  ? 'selected' : ''; ?>>Occupied</option>
                            <option value="reserved"  <?php echo (($_POST['status'] ?? '') === 'reserved')  ? 'selected' : ''; ?>>Reserved</option>
                        </select>
                    </div>

                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-gold px-5 rounded-pill">
                            <i class="bi bi-check-lg me-2"></i>Save Table
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
