<?php
// menu/delete.php — Delete a menu item
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php?error=Invalid request.'); exit; }

$stmt = $conn->prepare("DELETE FROM menu_items WHERE id = ?");
$stmt->bind_param('i', $id);
if ($stmt->execute() && $stmt->affected_rows > 0) {
    header('Location: index.php?success=Menu item deleted successfully!');
} else {
    header('Location: index.php?error=Could not delete item.');
}
$stmt->close();
exit;
?>
