<?php
// menu/add.php — Add new menu item
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Add Menu Item';
$rootPath  = '../';
$error = '';
$success = '';

// Fetch categories
$categories = $conn->query("SELECT * FROM categories ORDER BY category_name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = (int)($_POST['category_id'] ?? 0);
    $item_name   = trim($_POST['item_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price       = trim($_POST['price'] ?? '');
    $status      = $_POST['status'] ?? 'available';

    // Validation
    if (!$category_id || empty($item_name) || empty($price)) {
        $error = 'Category, item name, and price are required.';
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = 'Please enter a valid price.';
    } else {
        $stmt = $conn->prepare("INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES (?,?,?,?,?)");
        $stmt->bind_param('issds', $category_id, $item_name, $description, $price, $status);
        if ($stmt->execute()) {
            header('Location: index.php?success=Menu item added successfully!');
            exit;
        } else {
            $error = 'Failed to add item. Please try again.';
        }
        $stmt->close();
    }
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-plus-circle me-2" style="color:var(--gold);"></i>Add Menu Item</h2>
            <p>Add a new food or beverage item to the menu.</p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="form-card">
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label">Category *</label>
                        <select name="category_id" class="form-select" required>
                            <option value="">— Select Category —</option>
                            <?php while ($cat = $categories->fetch_assoc()): ?>
                            <option value="<?php echo $cat['id']; ?>"
                                <?php echo (($_POST['category_id'] ?? '') == $cat['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Item Name *</label>
                        <input type="text" name="item_name" class="form-control"
                               placeholder="e.g. Grilled Chicken"
                               value="<?php echo htmlspecialchars($_POST['item_name'] ?? ''); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3"
                                  placeholder="Brief description of the item..."><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Price (Rs.) *</label>
                            <input type="number" name="price" class="form-control" step="0.01" min="0"
                                   placeholder="0.00"
                                   value="<?php echo htmlspecialchars($_POST['price'] ?? ''); ?>" required>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label">Status *</label>
                            <select name="status" class="form-select">
                                <option value="available"   <?php echo (($_POST['status'] ?? 'available') === 'available')   ? 'selected' : ''; ?>>Available</option>
                                <option value="unavailable" <?php echo (($_POST['status'] ?? '') === 'unavailable') ? 'selected' : ''; ?>>Unavailable</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-gold px-5 rounded-pill">
                            <i class="bi bi-check-lg me-2"></i>Save Item
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
