<?php
// menu/index.php — View all menu items with search and filter
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Menu Items';
$rootPath  = '../';

// Success/error messages from redirects
$success = $_GET['success'] ?? '';
$error   = $_GET['error']   ?? '';

// Pagination
$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

// Filter by category
$catFilter = (int)($_GET['category'] ?? 0);
$statusFilter = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');

// Build WHERE clause
$where = "WHERE 1=1";
$params = [];
$types  = '';

if ($catFilter > 0)      { $where .= " AND mi.category_id = ?"; $params[] = $catFilter; $types .= 'i'; }
if ($statusFilter !== '') { $where .= " AND mi.status = ?";      $params[] = $statusFilter; $types .= 's'; }
if ($search !== '')       { $where .= " AND (mi.item_name LIKE ? OR mi.description LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; $types .= 'ss'; }

// Count total
$countSql = "SELECT COUNT(*) AS c FROM menu_items mi $where";
$stmt = $conn->prepare($countSql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];
$totalPages = ceil($total / $perPage);
$stmt->close();

// Fetch items
$sql = "SELECT mi.*, c.category_name FROM menu_items mi
        JOIN categories c ON mi.category_id = c.id
        $where ORDER BY mi.id DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$types   .= 'ii';
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$items = $stmt->get_result();
$stmt->close();

// Fetch categories for filter dropdown
$categories = $conn->query("SELECT * FROM categories ORDER BY category_name");

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
            <h2><i class="bi bi-menu-button-wide me-2" style="color:var(--gold);"></i>Menu Items</h2>
            <p>Manage all food and beverage items.</p>
        </div>
        <a href="add.php" class="btn btn-gold rounded-pill px-4">
            <i class="bi bi-plus-lg me-2"></i>Add Item
        </a>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-custom alert-success-custom auto-dismiss mb-3">
        <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <!-- Search & Filters -->
    <div class="data-card mb-3">
        <div class="p-3">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-4 search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" name="search" id="liveSearch" class="form-control"
                           placeholder="Search menu items..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <?php $categories->data_seek(0); while ($cat = $categories->fetch_assoc()): ?>
                        <option value="<?php echo $cat['id']; ?>" <?php echo ($catFilter == $cat['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category_name']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="available"   <?php echo ($statusFilter === 'available')   ? 'selected' : ''; ?>>Available</option>
                        <option value="unavailable" <?php echo ($statusFilter === 'unavailable') ? 'selected' : ''; ?>>Unavailable</option>
                    </select>
                </div>
                <div class="col-md-auto d-flex gap-2">
                    <button type="submit" class="btn btn-gold rounded-pill px-3">
                        <i class="bi bi-funnel me-1"></i>Filter
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="data-card">
        <div class="data-card-header">
            <h5>All Menu Items <span style="color:var(--text-muted);font-size:13px;font-family:'DM Sans';">(<?php echo $total; ?> records)</span></h5>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Price (Rs.)</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($items->num_rows === 0): ?>
                    <tr><td colspan="6" class="text-center py-4" style="color:var(--text-muted);">No menu items found.</td></tr>
                    <?php endif; ?>
                    <?php $sno = $offset + 1; while ($row = $items->fetch_assoc()): ?>
                    <tr class="searchable-row">
                        <td><?php echo $sno++; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($row['item_name']); ?></strong>
                            <?php if ($row['description']): ?>
                            <br><small style="color:var(--text-muted);"><?php echo htmlspecialchars(substr($row['description'],0,50)); ?>...</small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['category_name']); ?></td>
                        <td><strong style="color:var(--gold);">Rs. <?php echo number_format($row['price'],2); ?></strong></td>
                        <td>
                            <span class="badge-custom badge-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn-action btn-edit me-1" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <button class="btn-action btn-delete"
                                    onclick="confirmDelete('delete.php?id=<?php echo $row['id']; ?>', '<?php echo htmlspecialchars($row['item_name']); ?>')"
                                    title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="p-3 d-flex justify-content-end">
            <nav><ul class="pagination mb-0">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo $catFilter; ?>&status=<?php echo urlencode($statusFilter); ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
                <?php endfor; ?>
            </ul></nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
