<?php
// auth/login.php — Admin Login Page
session_start();

// Already logged in → go to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit;
}

require_once '../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Basic validation
    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        // Use prepared statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            // Verify password (hashed with password_hash)
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email']    = $user['email'];
                $_SESSION['role']     = $user['role'];
                header('Location: ../dashboard/index.php');
                exit;
            } else {
                $error = 'Invalid username or password.';
            }
        } else {
            $error = 'Invalid username or password.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | RestoPro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
</head>
<body class="login-page">

<div class="login-card">
    <!-- Logo -->
    <div class="login-logo">
        <i class="bi bi-egg-fried"></i>
    </div>

    <h2 class="text-center mb-1" style="font-size:26px; color:#E8E8F0;">Welcome Back</h2>
    <p class="text-center mb-4" style="color:#7A7A9A; font-size:14px;">Sign in to RestoPro Admin Panel</p>

    <!-- Error Alert -->
    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-4">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <!-- Login Form -->
    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label">Username or Email</label>
            <div class="search-box">
                <i class="bi bi-person"></i>
                <input type="text" name="username" class="form-control"
                       placeholder="Enter username or email"
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                       required autocomplete="username">
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label">Password</label>
            <div class="search-box">
                <i class="bi bi-lock"></i>
                <input type="password" name="password" class="form-control"
                       placeholder="Enter password"
                       required autocomplete="current-password">
            </div>
        </div>

        <button type="submit" class="btn btn-gold w-100 py-2 rounded-pill mb-3">
            <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
        </button>
    </form>

    <div class="text-center">
        <p style="color:#7A7A9A; font-size:13px;">Don't have an account?
            <a href="signup.php" style="color:#D4A843;">Create Account</a>
        </p>
    </div>

    <!-- Demo credentials hint -->
    <div class="mt-3 p-3 rounded-3" style="background:rgba(212,168,67,0.07); border:1px solid rgba(212,168,67,0.2);">
        <p class="mb-1" style="font-size:12px; color:#D4A843; font-weight:600;">
            <i class="bi bi-info-circle me-1"></i>Demo Credentials
        </p>
        <p class="mb-0" style="font-size:12px; color:#7A7A9A;">
            Username: <strong style="color:#E8E8F0;">admin</strong> &nbsp;|&nbsp;
            Password: <strong style="color:#E8E8F0;">password</strong>
        </p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/script.js"></script>
</body>
</html>
