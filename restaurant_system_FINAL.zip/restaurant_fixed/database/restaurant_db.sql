-- ============================================================
--  RESTAURANT MANAGEMENT SYSTEM — DATABASE
--  Created for University CRUD Project Submission
--  Compatible with XAMPP / phpMyAdmin / MySQL
-- ============================================================

-- Step 1: Create and use the database
CREATE DATABASE IF NOT EXISTS restaurant_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_db;

-- ============================================================
-- TABLE 1: users (Admin authentication)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,          -- Stored as hashed (password_hash)
    role ENUM('admin','staff') DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 2: categories (Food categories like Starters, Main, etc.)
-- ============================================================
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 3: menu_items (Restaurant menu / food items)
-- ============================================================
CREATE TABLE IF NOT EXISTS menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    item_name VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    status ENUM('available','unavailable') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 4: restaurant_tables (Physical tables in restaurant)
-- ============================================================
CREATE TABLE IF NOT EXISTS restaurant_tables (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_number VARCHAR(10) NOT NULL UNIQUE,
    capacity INT NOT NULL DEFAULT 4,
    status ENUM('available','occupied','reserved') DEFAULT 'available',
    location VARCHAR(100) DEFAULT 'Main Hall',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 5: customers
-- ============================================================
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 6: orders (Booking/Order header)
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    table_id INT NOT NULL,
    order_date DATE NOT NULL,
    total_amount DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('pending','confirmed','served','cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (table_id) REFERENCES restaurant_tables(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLE 7: order_items (Individual items within each order)
-- ============================================================
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_item_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- SAMPLE DATA INSERTS
-- ============================================================

-- Default admin user (password: admin123)
INSERT INTO users (username, email, password, role) VALUES
('admin', 'admin@restaurant.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('staff1', 'staff@restaurant.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'staff');

-- Categories
INSERT INTO categories (category_name, description) VALUES
('Starters', 'Appetizers and soups to begin your meal'),
('Main Course', 'Hearty main dishes for a full meal'),
('Desserts', 'Sweet treats to end your dining experience'),
('Beverages', 'Hot and cold drinks'),
('Fast Food', 'Quick bites and snacks');

-- Menu Items
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(1, 'Chicken Soup', 'Warm and comforting homemade chicken soup', 350.00, 'available'),
(1, 'Spring Rolls (6 pcs)', 'Crispy vegetable spring rolls with dipping sauce', 420.00, 'available'),
(1, 'Garlic Bread', 'Toasted bread with garlic butter and herbs', 250.00, 'available'),
(2, 'Grilled Chicken', 'Juicy grilled chicken with seasoned vegetables', 950.00, 'available'),
(2, 'Beef Steak', 'Premium beef steak cooked to perfection', 1800.00, 'available'),
(2, 'Spaghetti Bolognese', 'Classic Italian pasta with meat sauce', 750.00, 'available'),
(2, 'Chicken Biryani', 'Aromatic basmati rice with tender chicken pieces', 650.00, 'available'),
(2, 'Grilled Fish', 'Fresh fish fillet with lemon butter sauce', 1100.00, 'available'),
(3, 'Chocolate Lava Cake', 'Warm chocolate cake with molten center', 450.00, 'available'),
(3, 'Cheesecake', 'Creamy New York style cheesecake', 380.00, 'available'),
(3, 'Ice Cream (3 scoops)', 'Choice of vanilla, chocolate, or strawberry', 280.00, 'available'),
(4, 'Fresh Juice', 'Seasonal fresh fruit juice', 200.00, 'available'),
(4, 'Soft Drink', 'Pepsi, 7UP, or Mirinda', 120.00, 'available'),
(4, 'Mineral Water', 'Chilled bottled water', 80.00, 'available'),
(4, 'Coffee', 'Freshly brewed coffee with milk', 250.00, 'available'),
(5, 'Burger', 'Beef or chicken burger with fries', 550.00, 'available'),
(5, 'Pizza (8 inch)', 'Margherita or pepperoni personal pizza', 700.00, 'available'),
(5, 'French Fries', 'Crispy golden fries with ketchup', 200.00, 'available');

-- Restaurant Tables
INSERT INTO restaurant_tables (table_number, capacity, status, location) VALUES
('T-01', 2, 'available', 'Window Side'),
('T-02', 4, 'available', 'Main Hall'),
('T-03', 4, 'available', 'Main Hall'),
('T-04', 6, 'available', 'Main Hall'),
('T-05', 6, 'available', 'Garden Area'),
('T-06', 8, 'available', 'VIP Room'),
('T-07', 2, 'available', 'Window Side'),
('T-08', 4, 'available', 'Main Hall'),
('T-09', 4, 'reserved', 'Main Hall'),
('T-10', 10, 'available', 'Banquet Hall');

-- Customers
INSERT INTO customers (customer_name, email, phone, address) VALUES
('Ahmed Khan', 'ahmed@email.com', '0300-1234567', 'House 12, Gulberg, Lahore'),
('Sara Ali', 'sara@email.com', '0321-9876543', 'Flat 5B, DHA Phase 3, Karachi'),
('Muhammad Usman', 'usman@email.com', '0333-5556677', 'Street 7, F-8, Islamabad'),
('Fatima Malik', 'fatima@email.com', '0345-1122334', 'Block C, Johar Town, Lahore'),
('Ali Hassan', 'ali@email.com', '0311-4455667', 'Sector G-9, Islamabad'),
('Zara Sheikh', 'zara@email.com', '0322-7788990', 'Clifton Block 4, Karachi'),
('Omar Farooq', 'omar@email.com', '0300-9988776', 'Model Town, Lahore'),
('Ayesha Noor', 'ayesha@email.com', '0334-6677889', 'Bahria Town, Rawalpindi');

-- Orders
INSERT INTO orders (customer_id, table_id, order_date, total_amount, status, notes) VALUES
(1, 2, CURDATE(), 2050.00, 'served', 'Extra spicy please'),
(2, 5, CURDATE(), 1380.00, 'confirmed', 'Allergic to nuts'),
(3, 6, CURDATE(), 3200.00, 'pending', 'Anniversary dinner'),
(4, 1, CURDATE(), 670.00, 'served', ''),
(5, 3, DATE_SUB(CURDATE(),INTERVAL 1 DAY), 1750.00, 'served', ''),
(6, 4, DATE_SUB(CURDATE(),INTERVAL 1 DAY), 2300.00, 'served', 'Birthday celebration'),
(7, 7, DATE_SUB(CURDATE(),INTERVAL 2 DAY), 950.00, 'cancelled', ''),
(8, 8, DATE_SUB(CURDATE(),INTERVAL 2 DAY), 1430.00, 'served', '');

-- Order Items
INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price, subtotal) VALUES
(1, 4, 1, 950.00, 950.00),
(1, 6, 1, 750.00, 750.00),
(1, 10, 1, 380.00, 380.00),
(2, 7, 1, 650.00, 650.00),
(2, 13, 2, 120.00, 240.00),
(2, 9, 1, 450.00, 450.00),
(3, 5, 1, 1800.00, 1800.00),
(3, 8, 1, 1100.00, 1100.00),
(3, 15, 2, 80.00, 160.00),
(4, 16, 1, 550.00, 550.00),
(4, 13, 1, 120.00, 120.00),
(5, 4, 1, 950.00, 950.00),
(5, 3, 1, 250.00, 250.00),
(5, 12, 2, 200.00, 400.00),
(6, 5, 1, 1800.00, 1800.00),
(6, 2, 1, 420.00, 420.00),
(7, 4, 1, 950.00, 950.00),
(8, 17, 1, 700.00, 700.00),
(8, 18, 2, 200.00, 400.00),
(8, 15, 2, 120.00, 240.00);
