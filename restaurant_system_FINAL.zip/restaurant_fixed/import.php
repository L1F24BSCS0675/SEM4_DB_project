<?php
// ============================================================
// import.php — One-click database importer
// Open this in browser: http://localhost/restaurant_system/import.php
// ============================================================

$host = '127.0.0.1';
$user = 'root';
$pass = '';
$port = 3307;

echo "<!DOCTYPE html><html><head><title>DB Import</title>
<style>
body { font-family: Arial; padding: 40px; background: #f5f5f5; }
.box { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
h2 { color: #333; }
.ok { color: green; }
.err { color: red; }
.btn { display:inline-block; background:#D4A843; color:white; padding:12px 30px; border-radius:25px; text-decoration:none; font-weight:bold; margin-top:20px; }
</style></head><body><div class='box'>";

// Step 1: Connect
$conn = new mysqli($host, $user, $pass, '', $port);
if ($conn->connect_error) {
    die("<h2 class='err'>❌ Cannot connect to MySQL</h2>
    <p>Error: " . $conn->connect_error . "</p>
    <p>Make sure XAMPP MySQL is running!</p></div></body></html>");
}

// Step 2: Create database
$conn->query("CREATE DATABASE IF NOT EXISTS restaurant_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db("restaurant_db");

// Step 3: Read and run SQL
$sqlFile = __DIR__ . '/database/restaurant_db.sql';
if (!file_exists($sqlFile)) {
    die("<h2 class='err'>❌ SQL file not found!</h2><p>Expected at: database/restaurant_db.sql</p></div></body></html>");
}

$sql = file_get_contents($sqlFile);

// Split by semicolons carefully
$queries = array_filter(array_map('trim', explode(';', $sql)));
$success = 0; $failed = 0;

foreach ($queries as $query) {
    if (!empty($query) && $query !== '--') {
        if ($conn->query($query)) {
            $success++;
        } else {
            // Ignore duplicate/already-exists errors
            if ($conn->errno != 1050 && $conn->errno != 1060 && $conn->errno != 1007) {
                $failed++;
            }
        }
    }
}

echo "<h2 class='ok'>✅ Database Imported Successfully!</h2>
<p>✔ Queries executed: <strong>$success</strong></p>
<p>✔ Database: <strong>restaurant_db</strong> is ready</p>
<hr>
<p><strong>Login Credentials:</strong></p>
<p>👤 Username: <strong>admin</strong></p>
<p>🔑 Password: <strong>password</strong></p>
<a href='auth/login.php' class='btn'>👉 Open Restaurant System</a>
</div></body></html>";
?>
