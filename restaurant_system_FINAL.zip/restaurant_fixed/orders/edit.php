<?php
// orders/edit.php — Edit existing order status and notes
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Edit Order';
$rootPath  = '../';
$error = '';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$stmt = $conn->prepare("SELECT o.*, c.customer_name, rt.table_number FROM orders o JOIN customers c ON o.customer_id=c.id JOIN restaurant_tables rt ON o.table_id=rt.id WHERE o.id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$order) { header('Location: index.php?error=Order not found.'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? 'pending';
    $notes  = trim($_POST['notes'] ?? '');

    $stmt = $conn->prepare("UPDATE orders SET status=?, notes=? WHERE id=?");
    $stmt->bind_param('ssi', $status, $notes, $id);
    if ($stmt->execute()) {
        // If served/cancelled → free up the table
        if (in_array($status, ['served','cancelled'])) {
            $conn->query("UPDATE restaurant_tables SET status='available' WHERE id={$order['table_id']}");
        }
        header('Location: index.php?success=Order updated successfully!');
        exit;
    } else {
        $error = 'Update failed. Please try again.';
    }
    $stmt->close();
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-pencil-square me-2" style="color:var(--gold);"></i>Edit Order</h2>
            <p>Update status for Order <strong style="color:var(--gold);">#ORD-<?php echo str_pad($order['id'],4,'0',STR_PAD_LEFT); ?></strong></p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-6">
            <!-- Order Summary -->
            <div class="form-card mb-4" style="background:rgba(212,168,67,0.05);border-color:rgba(212,168,67,0.2);">
                <div class="row g-3 text-center">
                    <div class="col-4">
                        <div style="color:var(--text-muted);font-size:11px;text-transform:uppercase;letter-spacing:0.8px;">Customer</div>
                        <div style="font-weight:600;font-size:14px;"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                    </div>
                    <div class="col-4">
                        <div style="color:var(--text-muted);font-size:11px;text-transform:uppercase;letter-spacing:0.8px;">Table</div>
                        <div style="font-weight:600;font-size:14px;color:var(--gold);"><?php echo htmlspecialchars($order['table_number']); ?></div>
                    </div>
                    <div class="col-4">
                        <div style="color:var(--text-muted);font-size:11px;text-transform:uppercase;letter-spacing:0.8px;">Total</div>
                        <div style="font-weight:700;font-size:14px;color:var(--gold);">Rs. <?php echo number_format($order['total_amount'],2); ?></div>
                    </div>
                </div>
            </div>

            <div class="form-card">
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label">Order Status *</label>
                        <select name="status" class="form-select" required>
                            <option value="pending"   <?php echo ($order['status']==='pending')   ?'selected':''; ?>>⏳ Pending</option>
                            <option value="confirmed" <?php echo ($order['status']==='confirmed') ?'selected':''; ?>>✅ Confirmed</option>
                            <option value="served"    <?php echo ($order['status']==='served')    ?'selected':''; ?>>🍽️ Served</option>
                            <option value="cancelled" <?php echo ($order['status']==='cancelled') ?'selected':''; ?>>❌ Cancelled</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" class="form-control" rows="3"><?php echo htmlspecialchars($order['notes'] ?? ''); ?></textarea>
                    </div>

                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-gold px-5 rounded-pill">
                            <i class="bi bi-check-lg me-2"></i>Update Order
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-4">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
