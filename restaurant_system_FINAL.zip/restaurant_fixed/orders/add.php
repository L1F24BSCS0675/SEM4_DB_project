<?php
// orders/add.php — Place a new order
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'New Order';
$rootPath  = '../';
$error = '';

// Fetch customers and tables for dropdowns
$customers = $conn->query("SELECT id, customer_name, phone FROM customers ORDER BY customer_name");
$tables    = $conn->query("SELECT id, table_number, capacity, location FROM restaurant_tables WHERE status='available' ORDER BY table_number");
$menuItems = $conn->query("SELECT mi.id, mi.item_name, mi.price, c.category_name FROM menu_items mi JOIN categories c ON mi.category_id=c.id WHERE mi.status='available' ORDER BY c.category_name, mi.item_name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_id = (int)($_POST['customer_id'] ?? 0);
    $table_id    = (int)($_POST['table_id']    ?? 0);
    $order_date  = trim($_POST['order_date']   ?? '');
    $status      = $_POST['status']            ?? 'pending';
    $notes       = trim($_POST['notes']        ?? '');
    $item_ids    = $_POST['item_id']           ?? [];
    $quantities  = $_POST['quantity']          ?? [];

    // Validation
    if (!$customer_id || !$table_id || empty($order_date)) {
        $error = 'Customer, table, and date are required.';
    } elseif (empty($item_ids)) {
        $error = 'Please add at least one menu item to the order.';
    } else {
        // Calculate total
        $total = 0;
        $orderItems = [];
        foreach ($item_ids as $idx => $item_id) {
            $item_id = (int)$item_id;
            $qty     = max(1, (int)($quantities[$idx] ?? 1));
            // Get price from DB (safe: never trust POST price)
            $ps = $conn->prepare("SELECT price FROM menu_items WHERE id=?");
            $ps->bind_param('i', $item_id);
            $ps->execute();
            $pr = $ps->get_result()->fetch_assoc();
            $ps->close();
            if ($pr) {
                $subtotal = $pr['price'] * $qty;
                $total   += $subtotal;
                $orderItems[] = ['id' => $item_id, 'qty' => $qty, 'price' => $pr['price'], 'sub' => $subtotal];
            }
        }

        // Insert order header
        $ins = $conn->prepare("INSERT INTO orders (customer_id, table_id, order_date, total_amount, status, notes) VALUES (?,?,?,?,?,?)");
        $ins->bind_param('iisdss', $customer_id, $table_id, $order_date, $total, $status, $notes);
        if ($ins->execute()) {
            $order_id = $ins->insert_id;
            $ins->close();

            // Insert order items
            $ins2 = $conn->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price, subtotal) VALUES (?,?,?,?,?)");
            foreach ($orderItems as $oi) {
                $ins2->bind_param('iiddd', $order_id, $oi['id'], $oi['qty'], $oi['price'], $oi['sub']);
                $ins2->execute();
            }
            $ins2->close();

            // Mark table as occupied
            $conn->query("UPDATE restaurant_tables SET status='occupied' WHERE id=$table_id");

            header('Location: index.php?success=Order placed successfully!');
            exit;
        } else {
            $error = 'Failed to place order. Please try again.';
            $ins->close();
        }
    }
}

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-plus-circle me-2" style="color:var(--gold);"></i>New Order</h2>
            <p>Place a new customer order.</p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-arrow-left me-2"></i>Back
        </a>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <form method="POST">
        <div class="row g-4">
            <!-- Left: Order details -->
            <div class="col-lg-5">
                <div class="form-card mb-4">
                    <h5 class="mb-4" style="color:var(--gold);font-size:15px;">
                        <i class="bi bi-info-circle me-2"></i>Order Details
                    </h5>

                    <div class="mb-3">
                        <label class="form-label">Customer *</label>
                        <select name="customer_id" class="form-select" required>
                            <option value="">— Select Customer —</option>
                            <?php while ($c = $customers->fetch_assoc()): ?>
                            <option value="<?php echo $c['id']; ?>"
                                <?php echo (($_POST['customer_id'] ?? '') == $c['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($c['customer_name']); ?> — <?php echo $c['phone']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Table *</label>
                        <select name="table_id" class="form-select" required>
                            <option value="">— Select Table —</option>
                            <?php while ($t = $tables->fetch_assoc()): ?>
                            <option value="<?php echo $t['id']; ?>"
                                <?php echo (($_POST['table_id'] ?? '') == $t['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($t['table_number']); ?> — <?php echo $t['location']; ?> (<?php echo $t['capacity']; ?> pax)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Order Date *</label>
                        <input type="date" name="order_date" class="form-control"
                               value="<?php echo $_POST['order_date'] ?? date('Y-m-d'); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="pending"   <?php echo (($_POST['status'] ?? 'pending') === 'pending')   ? 'selected' : ''; ?>>Pending</option>
                            <option value="confirmed" <?php echo (($_POST['status'] ?? '') === 'confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                            <option value="served"    <?php echo (($_POST['status'] ?? '') === 'served')    ? 'selected' : ''; ?>>Served</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Notes / Special Instructions</label>
                        <textarea name="notes" class="form-control" rows="2"
                                  placeholder="e.g. Extra spicy, no onions..."><?php echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
                    </div>
                </div>

                <!-- Order Total -->
                <div class="form-card text-center">
                    <p style="color:var(--text-muted);font-size:13px;margin-bottom:6px;">ORDER TOTAL</p>
                    <div id="orderTotal" style="font-family:'Playfair Display',serif;font-size:32px;color:var(--gold);font-weight:700;">
                        Rs. 0.00
                    </div>
                    <button type="submit" class="btn btn-gold w-100 mt-3 rounded-pill py-2">
                        <i class="bi bi-check-lg me-2"></i>Place Order
                    </button>
                </div>
            </div>

            <!-- Right: Menu items -->
            <div class="col-lg-7">
                <div class="form-card">
                    <h5 class="mb-4" style="color:var(--gold);font-size:15px;">
                        <i class="bi bi-menu-button-wide me-2"></i>Select Menu Items
                    </h5>

                    <div id="itemsContainer">
                        <!-- Dynamic item rows injected here -->
                    </div>

                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4 mt-2"
                            onclick="addItemRow()">
                        <i class="bi bi-plus-lg me-2"></i>Add Item
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Build JS menu data from PHP -->
<script>
const menuData = [
    <?php
    $menuItems->data_seek(0);
    while ($m = $menuItems->fetch_assoc()) {
        echo "{id:" . $m['id'] . ", name:" . json_encode($m['item_name']) . ", price:" . $m['price'] . ", cat:" . json_encode($m['category_name']) . "},";
    }
    ?>
];

function addItemRow() {
    const container = document.getElementById('itemsContainer');
    const idx = container.querySelectorAll('.item-row').length;

    let options = '<option value="">— Select Item —</option>';
    let lastCat = '';
    menuData.forEach(function(item) {
        if (item.cat !== lastCat) {
            if (lastCat) options += '</optgroup>';
            options += `<optgroup label="${item.cat}">`;
            lastCat = item.cat;
        }
        options += `<option value="${item.id}" data-price="${item.price}">${item.name} — Rs. ${item.price.toFixed(2)}</option>`;
    });
    if (lastCat) options += '</optgroup>';

    const row = document.createElement('div');
    row.className = 'item-row row g-2 align-items-center mb-3 p-2 rounded-3';
    row.style.background = 'rgba(255,255,255,0.03)';
    row.innerHTML = `
        <div class="col-md-6">
            <select name="item_id[]" class="form-select item-select" onchange="onItemChange(this)" required>
                ${options}
            </select>
        </div>
        <div class="col-md-2">
            <input type="number" name="quantity[]" class="form-control item-qty" value="1" min="1"
                   placeholder="Qty">
        </div>
        <div class="col-md-3">
            <span class="item-price item-subtotal" data-price="0"
                  style="color:var(--gold);font-weight:600;font-size:14px;">Rs. 0.00</span>
        </div>
        <div class="col-md-1">
            <button type="button" class="btn-action btn-delete" onclick="this.closest('.item-row').remove(); calcOrderTotal();">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
    `;
    container.appendChild(row);
}

function onItemChange(sel) {
    const opt = sel.options[sel.selectedIndex];
    const price = parseFloat(opt.dataset.price) || 0;
    const row = sel.closest('.item-row');
    row.querySelector('.item-subtotal').dataset.price = price;
    calcOrderTotal();
}

// Init with one row
addItemRow();
</script>

<?php include_once '../includes/footer.php'; ?>
