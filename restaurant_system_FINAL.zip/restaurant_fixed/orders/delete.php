<?php
// orders/delete.php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php?error=Invalid request.'); exit; }

// Get table_id before deleting so we can free the table
$r = $conn->prepare("SELECT table_id FROM orders WHERE id=?");
$r->bind_param('i', $id);
$r->execute();
$row = $r->get_result()->fetch_assoc();
$r->close();

$stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
$stmt->bind_param('i', $id);
if ($stmt->execute() && $stmt->affected_rows > 0) {
    // Free the table
    if ($row) {
        $conn->query("UPDATE restaurant_tables SET status='available' WHERE id={$row['table_id']}");
    }
    header('Location: index.php?success=Order deleted successfully!');
} else {
    header('Location: index.php?error=Could not delete order.');
}
$stmt->close();
exit;
?>
