<?php
// orders/view.php — View detailed order receipt
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Order Details';
$rootPath  = '../';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

// Fetch order with joins
$stmt = $conn->prepare("
    SELECT o.*, c.customer_name, c.email, c.phone, rt.table_number, rt.location
    FROM orders o
    JOIN customers c ON o.customer_id = c.id
    JOIN restaurant_tables rt ON o.table_id = rt.id
    WHERE o.id = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$order) { header('Location: index.php?error=Order not found.'); exit; }

// Fetch order items
$itemsStmt = $conn->prepare("
    SELECT oi.*, mi.item_name, c.category_name
    FROM order_items oi
    JOIN menu_items mi ON oi.menu_item_id = mi.id
    JOIN categories c ON mi.category_id = c.id
    WHERE oi.order_id = ?
");
$itemsStmt->bind_param('i', $id);
$itemsStmt->execute();
$items = $itemsStmt->get_result();
$itemsStmt->close();

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-receipt me-2" style="color:var(--gold);"></i>Order Details</h2>
            <p>Full breakdown for Order #ORD-<?php echo str_pad($order['id'],4,'0',STR_PAD_LEFT); ?></p>
        </div>
        <div class="d-flex gap-2">
            <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-outline-secondary rounded-pill px-3">
                <i class="bi bi-pencil me-2"></i>Edit
            </a>
            <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">
                <i class="bi bi-arrow-left me-2"></i>Back
            </a>
        </div>
    </div>

    <div class="row g-4">
        <!-- Order Info -->
        <div class="col-lg-4">
            <div class="form-card">
                <h5 style="color:var(--gold);margin-bottom:20px;font-size:15px;">
                    <i class="bi bi-info-circle me-2"></i>Order Information
                </h5>
                <div style="display:flex;flex-direction:column;gap:14px;">
                    <div>
                        <div style="color:var(--text-muted);font-size:11px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px;">Order ID</div>
                        <div style="font-weight:700;color:var(--gold);">#ORD-<?php echo str_pad($order['id'],4,'0',STR_PAD_LEFT); ?></div>
                    </div>
                    <div>
                        <div style="color:var(--text-muted);font-size:11px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px;">Customer</div>
                        <div><?php echo htmlspecialchars($order['customer_name']); ?></div>
                        <div style="color:var(--text-muted);font-size:12px;"><?php echo htmlspecialchars($order['phone']); ?></div>
                    </div>
                    <div>
                        <div style="color:var(--text-muted);font-size:11px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px;">Table</div>
                        <div><?php echo htmlspecialchars($order['table_number']); ?> — <?php echo htmlspecialchars($order['location']); ?></div>
                    </div>
                    <div>
                        <div style="color:var(--text-muted);font-size:11px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px;">Order Date</div>
                        <div><?php echo date('d M Y', strtotime($order['order_date'])); ?></div>
                    </div>
                    <div>
                        <div style="color:var(--text-muted);font-size:11px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px;">Status</div>
                        <span class="badge-custom badge-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span>
                    </div>
                    <?php if ($order['notes']): ?>
                    <div>
                        <div style="color:var(--text-muted);font-size:11px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;margin-bottom:3px;">Notes</div>
                        <div style="font-size:13px;color:var(--text-muted);"><?php echo htmlspecialchars($order['notes']); ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Order Items -->
        <div class="col-lg-8">
            <div class="data-card">
                <div class="data-card-header">
                    <h5><i class="bi bi-bag me-2" style="color:var(--gold);"></i>Ordered Items</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark-custom mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item</th>
                                <th>Category</th>
                                <th>Unit Price</th>
                                <th>Qty</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $sno = 1; while ($item = $items->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $sno++; ?></td>
                                <td><strong><?php echo htmlspecialchars($item['item_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($item['category_name']); ?></td>
                                <td>Rs. <?php echo number_format($item['unit_price'],2); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><strong style="color:var(--gold);">Rs. <?php echo number_format($item['subtotal'],2); ?></strong></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5" class="text-end" style="font-weight:700;color:var(--text-muted);font-size:13px;padding:16px;">TOTAL AMOUNT</td>
                                <td style="font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--gold);padding:16px;">
                                    Rs. <?php echo number_format($order['total_amount'],2); ?>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
