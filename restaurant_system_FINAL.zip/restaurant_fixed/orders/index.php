<?php
// orders/index.php — View all orders
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }
require_once '../config/db.php';

$pageTitle = 'Orders';
$rootPath  = '../';
$success = $_GET['success'] ?? '';
$error   = $_GET['error']   ?? '';
$search  = trim($_GET['search'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where = "WHERE 1=1"; $params = []; $types = '';
if ($search !== '') {
    $where .= " AND (c.customer_name LIKE ? OR rt.table_number LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%"; $types .= 'ss';
}
if ($statusFilter !== '') {
    $where .= " AND o.status = ?"; $params[] = $statusFilter; $types .= 's';
}

$countSql = "SELECT COUNT(*) AS c FROM orders o JOIN customers c ON o.customer_id=c.id JOIN restaurant_tables rt ON o.table_id=rt.id $where";
$countStmt = $conn->prepare($countSql);
if ($params) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['c'];
$totalPages = ceil($total / $perPage);
$countStmt->close();

$p2 = $params; $p2[] = $perPage; $p2[] = $offset; $t2 = $types . 'ii';
$sql = "SELECT o.*, c.customer_name, rt.table_number
        FROM orders o
        JOIN customers c  ON o.customer_id = c.id
        JOIN restaurant_tables rt ON o.table_id = rt.id
        $where ORDER BY o.id DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param($t2, ...$p2);
$stmt->execute();
$orders = $stmt->get_result();
$stmt->close();

include_once '../includes/header.php';
?>

<div class="p-4">
    <div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
            <h2><i class="bi bi-receipt me-2" style="color:var(--gold);"></i>Orders</h2>
            <p>Track and manage all customer orders.</p>
        </div>
        <a href="add.php" class="btn btn-gold rounded-pill px-4">
            <i class="bi bi-plus-lg me-2"></i>New Order
        </a>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-custom alert-success-custom auto-dismiss mb-3">
        <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-custom alert-danger-custom auto-dismiss mb-3">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="data-card mb-3">
        <div class="p-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-4 search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" name="search" class="form-control"
                           placeholder="Search customer or table..."
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="pending"   <?php echo ($statusFilter==='pending')   ?'selected':''; ?>>Pending</option>
                        <option value="confirmed" <?php echo ($statusFilter==='confirmed') ?'selected':''; ?>>Confirmed</option>
                        <option value="served"    <?php echo ($statusFilter==='served')    ?'selected':''; ?>>Served</option>
                        <option value="cancelled" <?php echo ($statusFilter==='cancelled') ?'selected':''; ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-auto d-flex gap-2">
                    <button type="submit" class="btn btn-gold rounded-pill px-4">
                        <i class="bi bi-funnel me-1"></i>Filter
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary rounded-pill px-3">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="data-card">
        <div class="data-card-header">
            <h5>All Orders <span style="color:var(--text-muted);font-size:13px;font-family:'DM Sans';">(<?php echo $total; ?> records)</span></h5>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Table</th>
                        <th>Order Date</th>
                        <th>Total (Rs.)</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($orders->num_rows === 0): ?>
                    <tr><td colspan="7" class="text-center py-4" style="color:var(--text-muted);">No orders found.</td></tr>
                    <?php endif; ?>
                    <?php while ($row = $orders->fetch_assoc()): ?>
                    <tr class="searchable-row">
                        <td><strong style="color:var(--gold);">#ORD-<?php echo str_pad($row['id'],4,'0',STR_PAD_LEFT); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['table_number']); ?></td>
                        <td><?php echo date('d M Y', strtotime($row['order_date'])); ?></td>
                        <td><strong>Rs. <?php echo number_format($row['total_amount'],2); ?></strong></td>
                        <td>
                            <span class="badge-custom badge-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="view.php?id=<?php echo $row['id']; ?>" class="btn-action me-1"
                               style="background:rgba(212,168,67,0.15);color:var(--gold);" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn-action btn-edit me-1" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <button class="btn-action btn-delete"
                                    onclick="confirmDelete('delete.php?id=<?php echo $row['id']; ?>', 'Order #ORD-<?php echo str_pad($row['id'],4,'0',STR_PAD_LEFT); ?>')"
                                    title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php if ($totalPages > 1): ?>
        <div class="p-3 d-flex justify-content-end">
            <nav><ul class="pagination mb-0">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($statusFilter); ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
            </ul></nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
