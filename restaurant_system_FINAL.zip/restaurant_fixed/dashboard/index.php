<?php
// dashboard/index.php — Admin Dashboard with statistics
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}
require_once '../config/db.php';

$pageTitle = 'Dashboard';
$rootPath  = '../';

// ---- Fetch statistics ----
$stats = [];

// Total menu items
$r = $conn->query("SELECT COUNT(*) AS c FROM menu_items");
$stats['menu'] = $r->fetch_assoc()['c'];

// Total tables
$r = $conn->query("SELECT COUNT(*) AS c FROM restaurant_tables");
$stats['tables'] = $r->fetch_assoc()['c'];

// Available tables
$r = $conn->query("SELECT COUNT(*) AS c FROM restaurant_tables WHERE status='available'");
$stats['tables_available'] = $r->fetch_assoc()['c'];

// Total customers
$r = $conn->query("SELECT COUNT(*) AS c FROM customers");
$stats['customers'] = $r->fetch_assoc()['c'];

// Total orders
$r = $conn->query("SELECT COUNT(*) AS c FROM orders");
$stats['orders'] = $r->fetch_assoc()['c'];

// Today's orders
$r = $conn->query("SELECT COUNT(*) AS c FROM orders WHERE order_date = CURDATE()");
$stats['today_orders'] = $r->fetch_assoc()['c'];

// Total revenue (served orders only)
$r = $conn->query("SELECT IFNULL(SUM(total_amount),0) AS rev FROM orders WHERE status='served'");
$stats['revenue'] = number_format($r->fetch_assoc()['rev'], 2);

// Pending orders
$r = $conn->query("SELECT COUNT(*) AS c FROM orders WHERE status='pending'");
$stats['pending'] = $r->fetch_assoc()['c'];

// Recent 8 orders
$recentOrders = $conn->query("
    SELECT o.id, c.customer_name, rt.table_number, o.total_amount, o.status, o.order_date
    FROM orders o
    JOIN customers c ON o.customer_id = c.id
    JOIN restaurant_tables rt ON o.table_id = rt.id
    ORDER BY o.created_at DESC
    LIMIT 8
");

include_once '../includes/header.php';
?>

<div class="p-4">
    <!-- Page Header -->
    <div class="page-header">
        <h2><i class="bi bi-speedometer2 me-2" style="color:var(--gold);"></i>Dashboard</h2>
        <p>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! Here's your restaurant overview.</p>
    </div>

    <!-- Stats Row 1 -->
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="stat-card gold">
                <div class="stat-icon gold"><i class="bi bi-menu-button-wide"></i></div>
                <div class="stat-number"><?php echo $stats['menu']; ?></div>
                <div class="stat-label">Menu Items</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card green">
                <div class="stat-icon green"><i class="bi bi-grid-3x3-gap"></i></div>
                <div class="stat-number"><?php echo $stats['tables_available']; ?> <small style="font-size:16px;color:var(--text-muted);">/ <?php echo $stats['tables']; ?></small></div>
                <div class="stat-label">Available Tables</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card blue">
                <div class="stat-icon blue"><i class="bi bi-people"></i></div>
                <div class="stat-number"><?php echo $stats['customers']; ?></div>
                <div class="stat-label">Total Customers</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card red">
                <div class="stat-icon red"><i class="bi bi-receipt"></i></div>
                <div class="stat-number"><?php echo $stats['orders']; ?></div>
                <div class="stat-label">Total Orders</div>
            </div>
        </div>
    </div>

    <!-- Stats Row 2 -->
    <div class="row g-3 mb-4">
        <div class="col-xl-4 col-md-6">
            <div class="stat-card">
                <div class="stat-icon purple"><i class="bi bi-currency-dollar"></i></div>
                <div class="stat-number" style="font-size:22px;">Rs. <?php echo $stats['revenue']; ?></div>
                <div class="stat-label">Total Revenue (Served)</div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6">
            <div class="stat-card">
                <div class="stat-icon orange"><i class="bi bi-clock-history"></i></div>
                <div class="stat-number"><?php echo $stats['pending']; ?></div>
                <div class="stat-label">Pending Orders</div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6">
            <div class="stat-card">
                <div class="stat-icon green"><i class="bi bi-calendar-check"></i></div>
                <div class="stat-number"><?php echo $stats['today_orders']; ?></div>
                <div class="stat-label">Today's Orders</div>
            </div>
        </div>
    </div>

    <!-- Recent Orders Table -->
    <div class="data-card">
        <div class="data-card-header">
            <h5><i class="bi bi-receipt me-2" style="color:var(--gold);"></i>Recent Orders</h5>
            <a href="../orders/index.php" class="btn btn-gold btn-sm rounded-pill px-3">
                View All <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
        <div class="table-responsive">
            <table class="table table-dark-custom recent-table mb-0">
                <thead>
                    <tr>
                        <th>#Order</th>
                        <th>Customer</th>
                        <th>Table</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $recentOrders->fetch_assoc()): ?>
                    <tr>
                        <td>#ORD-<?php echo str_pad($row['id'], 4, '0', STR_PAD_LEFT); ?></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['table_number']); ?></td>
                        <td>Rs. <?php echo number_format($row['total_amount'], 2); ?></td>
                        <td><?php echo date('d M Y', strtotime($row['order_date'])); ?></td>
                        <td>
                            <span class="badge-custom badge-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include_once '../includes/footer.php'; ?>
