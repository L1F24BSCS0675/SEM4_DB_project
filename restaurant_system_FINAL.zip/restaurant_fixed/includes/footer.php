
    </div><!-- /main-content -->
</div><!-- /wrapper -->

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="<?php echo $rootPath ?? '../'; ?>js/script.js"></script>
</body>
</html>
