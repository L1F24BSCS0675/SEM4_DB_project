<?php
// includes/header.php — Common HTML head + Bootstrap + navbar
// Included at top of every page
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | RestoPro' : 'RestoPro Admin'; ?></title>

    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo $rootPath ?? '../'; ?>css/style.css" rel="stylesheet">
</head>
<body>
<!-- TOP NAVBAR -->
<nav class="navbar navbar-expand-lg top-navbar px-4">
    <a class="navbar-brand d-flex align-items-center gap-2" href="#">
        <span class="brand-icon"><i class="bi bi-egg-fried"></i></span>
        <span class="brand-name">RestoPro</span>
    </a>
    <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <i class="bi bi-list text-white fs-4"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto align-items-center gap-2">
            <li class="nav-item">
                <span class="nav-text text-white-50 small">
                    <i class="bi bi-person-circle me-1"></i>
                    Welcome, <strong class="text-white"><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></strong>
                </span>
            </li>
            <li class="nav-item">
                <a class="btn btn-outline-light btn-sm rounded-pill px-3" href="<?php echo $rootPath ?? '../'; ?>auth/logout.php">
                    <i class="bi bi-box-arrow-right me-1"></i>Logout
                </a>
            </li>
        </ul>
    </div>
</nav>

<div class="wrapper d-flex">
<?php include_once __DIR__ . '/sidebar.php'; ?>
<div class="main-content flex-grow-1">
