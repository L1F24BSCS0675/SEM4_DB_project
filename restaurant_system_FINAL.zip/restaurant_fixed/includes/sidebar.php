<?php
// includes/sidebar.php — Admin Sidebar Navigation
$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));

function isActive($dir, $currentDir) {
    return ($currentDir === $dir) ? 'active' : '';
}
?>
<div class="sidebar d-flex flex-column" id="sidebar">
    <div class="sidebar-logo text-center py-4">
        <div class="logo-circle mx-auto mb-2">
            <i class="bi bi-egg-fried fs-3 text-warning"></i>
        </div>
        <p class="text-white-50 small mb-0">Management Panel</p>
    </div>

    <nav class="sidebar-nav flex-grow-1 px-2">
        <ul class="nav flex-column gap-1">

            <li class="nav-section-label">MAIN</li>

            <li class="nav-item">
                <a href="<?php echo $rootPath ?? '../'; ?>dashboard/index.php"
                   class="nav-link sidebar-link <?php echo isActive('dashboard', $currentDir); ?>">
                    <i class="bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li class="nav-section-label mt-3">MANAGEMENT</li>

            <li class="nav-item">
                <a href="<?php echo $rootPath ?? '../'; ?>menu/index.php"
                   class="nav-link sidebar-link <?php echo isActive('menu', $currentDir); ?>">
                    <i class="bi bi-menu-button-wide"></i>
                    <span>Menu Items</span>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo $rootPath ?? '../'; ?>tables/index.php"
                   class="nav-link sidebar-link <?php echo isActive('tables', $currentDir); ?>">
                    <i class="bi bi-grid-3x3-gap"></i>
                    <span>Tables</span>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo $rootPath ?? '../'; ?>customers/index.php"
                   class="nav-link sidebar-link <?php echo isActive('customers', $currentDir); ?>">
                    <i class="bi bi-people"></i>
                    <span>Customers</span>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo $rootPath ?? '../'; ?>orders/index.php"
                   class="nav-link sidebar-link <?php echo isActive('orders', $currentDir); ?>">
                    <i class="bi bi-receipt"></i>
                    <span>Orders</span>
                </a>
            </li>

        </ul>
    </nav>

    <div class="sidebar-footer px-3 py-3">
        <div class="d-flex align-items-center gap-2">
            <div class="avatar-circle">
                <i class="bi bi-person-fill text-warning"></i>
            </div>
            <div>
                <div class="text-white small fw-semibold"><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></div>
                <div class="text-white-50" style="font-size:11px;"><?php echo ucfirst($_SESSION['role'] ?? 'admin'); ?></div>
            </div>
        </div>
    </div>
</div>
